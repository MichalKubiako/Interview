package iv.project

object Names {

    val listOfNames = mutableListOf(
        "Liam",
        "Olivia",
        "Noah",
        "Emma",
        "Oliver",
        "Charlotte",
        "Elijah",
        "Amelia",
        "Theodore",
        "James",
        "Sophia",
        "Isabella",
        "William"
    )

}