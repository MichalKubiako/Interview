package iv.project

import kotlinx.coroutines.delay
import java.util.*

object UtilUUID {
    suspend fun getRandomUUID(): String {
        delay(1000)
        return UUID.randomUUID().toString()
    }
}