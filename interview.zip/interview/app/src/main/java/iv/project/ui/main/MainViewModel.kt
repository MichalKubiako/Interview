package iv.project.ui.main

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import iv.project.problemIsInHere.SomeService

class MainViewModel : ViewModel() {

    var namesWithIds = MutableLiveData<List<String>>()
    var loading = MutableLiveData(false)
    var time = MutableLiveData<Long>()

    fun getDataFromSomeService() {
        val startTime = System.currentTimeMillis()
        loading.postValue(true)
        SomeService.getNames { list ->
            namesWithIds.postValue(list)
            loading.postValue(false)
            time.postValue(System.currentTimeMillis() - startTime)
        }
    }
}