package iv.project.problemIsInHere

import iv.project.Names.listOfNames
import iv.project.UtilUUID
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

object SomeService {

    fun getNames(something: (List<String>) -> Unit) {
        CoroutineScope(Dispatchers.IO).launch {
            something(
                SomeApi.getData()
            )
        }
    }
}

object SomeApi {

    suspend fun getData(): MutableList<String> {
        val list = mutableListOf<String>()
        listOfNames.forEach { name ->
            list.add("$name (${UtilUUID.getRandomUUID()})")
        }
        return list
    }
}