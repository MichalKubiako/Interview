package iv.project.ui.main

import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.view.isVisible
import iv.project.R
import iv.project.databinding.FragmentMainBinding

class MainFragment : Fragment() {

    companion object {
        fun newInstance() = MainFragment()
    }

    private lateinit var viewModel: MainViewModel
    private lateinit var binding: FragmentMainBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentMainBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel = ViewModelProvider(this)[MainViewModel::class.java]
        viewModel.namesWithIds.observe(viewLifecycleOwner) {
            binding.textView.text = it.joinToString("\n")
        }
        viewModel.loading.observe(viewLifecycleOwner) { state ->
            binding.button.isVisible = !state
            binding.progressBar.isVisible = state
        }
        viewModel.time.observe(viewLifecycleOwner) { time ->
            Toast.makeText(
                requireContext(),
                "It took: $time ms",
                Toast.LENGTH_SHORT
            ).show()
        }
        binding.button.setOnClickListener {
            binding.textView.text = ""
            viewModel.getDataFromSomeService()
        }
    }
}